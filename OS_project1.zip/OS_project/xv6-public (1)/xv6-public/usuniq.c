#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

#define LINE_MAX 1024
char custom_tolowercase(char c) {
    if (c >= 'A' && c <= 'Z') {
        return c + 'a' - 'A';
    }
    return c;
}


int stricmp1(const char *str1, const char *str2) {
    while (*str1 && *str2) {
        int differ = custom_tolowercase(*str1) - custom_tolowercase(*str2);
        if (differ != 0) {
            return differ;
        }
        str1++;
        str2++;
    }
    return custom_tolowercase(*str1) - custom_tolowercase(*str2);
}

int main(int argc, char *argv[]) {

    printf(1, "In user mode uniq is getting executed.\n");

    char *filename1;
    int counter=0;
    int dupli_line=0;

    int dp=0;
    int ct=0;
    int ignore_case=0;

    char curline[LINE_MAX];
    char previous_line[LINE_MAX] = "";
    int first_line = 1;

   
    int lenofline = 0;

    if(argc==1)
    {

        while (1) {
        char c;
        int n = read(0, &c, sizeof(char));

        if (n <= 0)
            break;

        curline[lenofline] = c;
        lenofline++;

        if (c == '\n') {
            curline[lenofline] = '\0';
            lenofline = 0;

            if (strcmp(curline, previous_line) != 0 || first_line) {
                printf(1, "%s", curline);
                strcpy(previous_line, curline);
                first_line = 0;
            }
        }
    }
    exit();

    }
    if (argc == 2)
    {
        filename1=argv[1];
    }
    else if(argc == 3)
    {
        filename1=argv[2];
        for (int i = 1; i < argc - 1; i++)
        {
            if (argv[i][0] == '-')
            {
                for (int j = 1; argv[i][j] != '\0'; j++) {
                    if (argv[i][j] == 'c') {
                        ct = 1;
                    } else if (argv[i][j] == 'i') {
                        ignore_case = 1;
                    } else if (argv[i][j] == 'd') {
                        dp = 1;
                    } else {
                        printf(2, "It is an Invalid option '%s''\n", argv[i]);
                        exit();
                    }
                }
            }
            else
            {
                printf(2, "It is an Invalid argument '%s'\n", argv[i]);
                exit();
            }

     }

    }
    else
    {
    printf(2, "Error:Please use: %s [-c] [-i] [-d] <filename1\n>", argv[0]);
    exit();
    }


    int file_des = open(filename1, O_RDONLY);

    if (file_des < 0) {
        printf(1, "Cannot open the file %s\n", filename1);
        exit();
    }


    while (1) {
        char c;
        int n = read(file_des, &c, sizeof(char));
      
        if (n <= 0)
            break;

        curline[lenofline] = c;
        lenofline++;

        if (c == '\n') {
            curline[lenofline] = '\0';
            lenofline = 0;

            int compareresult;

            if(ignore_case==1)
            {
                compareresult=stricmp1(curline, previous_line);
            }
            else
            {
               compareresult=strcmp(curline, previous_line);
            }

            if (compareresult != 0 || first_line==1)
            {

                if (ct==1 && !first_line)
                {
                     printf(1, "%d %s", counter, previous_line);
                   
                }
                if (dupli_line==1 && dp==1)
                {
                    printf(1, "%s", previous_line); 
                    dupli_line = 0; 
                }
                if(ignore_case==1)
                {
                printf(1, "%s", curline);
                }
                if(argc==2)
                {
                printf(1, "%s", curline);
                }


                counter = 1;
                strcpy(previous_line, curline);
                first_line = 0;
            }
            else
            {
                if(dp==1)
                {
                    dupli_line=1;
                }
                counter++;
            }
        }
    }

    if (ct && counter > 0) {
        printf(1, "%d %s", counter, previous_line);
    }
    if (dp && dupli_line)
    {
        printf(1, "%s", previous_line);
    }
    close(file_des);
    exit();
}