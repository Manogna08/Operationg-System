#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

#define LINE_MAX 1024
char custom_tolowercase(char c) {
    if (c >= 'A' && c <= 'Z') {
        return c + 'a' - 'A';
    }
    return c;
}

int stricmp1(const char *str1, const char *str2) {
    while (*str1 && *str2) {
        int difference = custom_tolowercase(*str1) - custom_tolowercase(*str2);
        if (difference != 0) {
            return difference;
        }
        str1++;
        str2++;
    }
    return custom_tolowercase(*str1) - custom_tolowercase(*str2);
}

int main(int argc, char *argv[]) {

    printf(1, "In kernel mode uniq is getting executed.\n");

    char *filename1;

    int dp=0;
    int ct=0;
    int ignore_case=0;

    char curline[LINE_MAX];
    char previous_line[LINE_MAX] = "";
    int firstline = 1;

    
    int lenofline = 0;

    if(argc==1)
    {

        while (1) {
        char c;
        int n = read(0, &c, sizeof(char));

        if (n <= 0)
            break;

        curline[lenofline] = c;
        lenofline++;

        if (c == '\n') {
            curline[lenofline] = '\0';
            lenofline = 0;

            if (strcmp(curline, previous_line) != 0 || firstline) {
                printf(1, "%s", curline);
                strcpy(previous_line, curline);
                firstline = 0;
            }
        }
    }
    exit();

    }
    if (argc == 2)
    {
        filename1=argv[1];
    }
    else if(argc == 3)
    {
        filename1=argv[2];
        for (int i = 1; i < argc - 1; i++)
        {
            if (argv[i][0] == '-')
            {
                for (int j = 1; argv[i][j] != '\0'; j++) {
                    if (argv[i][j] == 'c') {
                        ct = 1;
                    } else if (argv[i][j] == 'i') {
                        ignore_case = 1;
                    } else if (argv[i][j] == 'd') {
                        dp = 1;
                    } else {
                        printf(2, "It is an Invalid option '%s''\n", argv[i]);
                        exit();
                    }
                }
            }
            else
            {
                printf(2, "It is Invalid argument '%s'\n", argv[i]);
                exit();
            }

     }

    }
    else
    {
    printf(2, "Error: Please use:%s [-c] [-i] [-d] <filename>\n", argv[0]);
    exit();
    }


    int file_des = open(filename1, O_RDONLY);

    if (file_des < 0) {
        printf(1, "Cannot open the file %s\n", filename1);
        exit();
    }

    uniq(file_des,dp,ct,ignore_case,argc);

    close(file_des);
    exit();
}