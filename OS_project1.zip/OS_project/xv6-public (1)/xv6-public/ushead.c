#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

#define LENGTH_MAX 1024
void emphead()
{
int ct=0;
 while(ct<14){
   char buff[1024];  // Create a buff to store the input data
    // Use the read system call to read from stdin (file descriptor 0)
    int bytesTranfer = read(0, buff, sizeof(buff));

    if (bytesTranfer < 0) {
        printf(1,"The error is  Stdin Error \n");
        exit();
    }
    for (int i = 0; i < bytesTranfer; i++) {
            printf(1, "%c", buff[i]);

    }
    ct++;

 }
 exit();
}
void ushead(int file_des, int numoflines) {
    char curline[LENGTH_MAX];
    int bytesTranfer;
    int linesPrinted = 0;

    while ((bytesTranfer = read(file_des, curline, sizeof(curline))) > 0 && linesPrinted < numoflines) {
        for (int i = 0; i < bytesTranfer; i++) {
            if (linesPrinted >= numoflines) {
                break;
            }
            printf(1, "%c", curline[i]);

            if (curline[i] == '\n') {
                linesPrinted++;
            }
        }
    }
}

int main(int argc, char *argv[]) {

    int numoflines = 14;  // Default number of lines to print
    char *filename1="";

    // //head
    printf(1,"Head command is getting executed in user mode \n");
    if(argc==1)
    {
        emphead();
    }

    // //heaf f1
    else if (argc == 2) {
        filename1 = argv[1];
    }

    // //head f1 f2

    else if((argc >= 3) && strcmp(argv[1], "-n") != 0)
    {

        for (int i = 1; i < argc; i++)
         {
            int file_des = open(argv[i], O_RDONLY);
            if (file_des < 0) {
                printf(2, "cannot open the file '%s' you are looking for:file doesn't exist \n", argv[i]);
                continue;
            }

            if (argc > 2) {
                printf(1, "++++++++++++++> %s <+++++++++++++\n", argv[i]);
            }

            ushead(file_des, numoflines);
            close(file_des);
        }

    exit();

    }
    //head -n 5 f1
    else if (argc == 4 && strcmp(argv[1], "-n") == 0)
    {
        numoflines = atoi(argv[2]);
       
        filename1 = argv[3];
    }

    else if(argc>4 && strcmp(argv[1], "-n") == 0)
    {
        numoflines = atoi(argv[2]);
        for (int i = 3; i < argc; i++)
         {
            int file_des = open(argv[i], O_RDONLY);
            if (file_des < 0) {
                printf(2, "cannot open the file '%s' you are looking for:file doesn't exist \n", argv[i]);
                continue;
            }

            if (argc > 2) {
                printf(1, "++> %s <++\n", argv[i]);
            }

            ushead(file_des, numoflines);
            close(file_des);
        }

        exit();

    }


    else {
        printf(2, "Expected Syntax is head [-n N] <filename1>\n");
        exit();
    }

    int file_des = open(filename1, O_RDONLY);

    if (file_des < 0) {
        printf(2, "cannot open the file '%s' you are looking for:file doesn't exist \n", filename1);
        exit();
    }

    ushead(file_des, numoflines);
    
    close(file_des);
    exit();
}

