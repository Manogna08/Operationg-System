#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

#define LENGTH_MAX 1024
void emphead()
{
int ct=0;
 while(ct<14){
   char buff[1024]; 
    int bytesTranfer = read(0, buff, sizeof(buff));

    if (bytesTranfer < 0) {
        printf(1,"The error is Stdin Error \n");
        exit();
    }
    for (int i = 0; i < bytesTranfer; i++) {
            printf(1, "%c", buff[i]);

    }
    ct++;

 }
 exit();
}
void ushead(int file_des, int numoflines) {
    char curline[LENGTH_MAX];
    int bytesTranfer;
    int linesPrinted = 0;

    while ((bytesTranfer = read(file_des, curline, sizeof(curline))) > 0 && linesPrinted < numoflines) {
        for (int i = 0; i < bytesTranfer; i++) {
            if (linesPrinted >= numoflines) {
                break;
            }
            printf(1, "%c", curline[i]);

            if (curline[i] == '\n') {
                linesPrinted++;
            }
        }
    }
}

int main(int argc, char *argv[]) {



    int numoflines = 14;  
    char *filename1="";

    printf(1,"Head command is getting executed in kernel mode \n");
    if(argc==1)
    {
        emphead();
    }

    
    else if (argc == 2) {
        filename1 = argv[1];
    }


    else if((argc >= 3) && strcmp(argv[1], "-n") != 0)
    {

        for (int i = 1; i < argc; i++)
         {
            int file_des = open(argv[i], O_RDONLY);
            if (file_des < 0) {
                printf(2, "cannot open the file '%s' you are looking for:file doesn't exist \n", argv[i]);
                continue;
            }

            if (argc > 2) {
                printf(1, "++++++++++++++> %s <+++++++++++++\n", argv[i]);
            }

            head(file_des, numoflines);
            close(file_des);
        }

    exit();

    }
    
    else if (argc == 4 && strcmp(argv[1], "-n") == 0)
    {
        numoflines = atoi(argv[2]);
        filename1 = argv[3];
    }

    else if(argc>4 && strcmp(argv[1], "-n") == 0)
    {
        numoflines = atoi(argv[2]);
        for (int i = 3; i < argc; i++)
         {
            int file_des = open(argv[i], O_RDONLY);
            if (file_des < 0) {
                printf(2, "cannot open the file '%s' you are looking for:file doesn't exist \n", argv[i]);
                continue;
            }

            if (argc > 2) {
                printf(1, "++> %s <++\n", argv[i]);
            }

            head(file_des, numoflines);
            close(file_des);
        }

        exit();

    }


    else {
        printf(2, "Expected Syntax is head [-n N] <filename1>\n");
        exit();
    }

    int file_des = open(filename1, O_RDONLY);

    if (file_des < 0) {
        printf(2, "cannot open the file '%s' you are looking for:file doesn't exist \n", filename1);
        exit();
    }

    //printf(1,"file_des-%d",file_des);
    head(file_des, numoflines);
    //printf(1,"%s",bufhere);
    //int pid = getpid();
    //printf(1, "Current process PID: %d\n", pid);
    close(file_des);
    exit();
}

