

#include "types.h"
#include "defs.h"
#include "param.h"
#include "stat.h"
#include "mmu.h"
#include "proc.h"
#include "fs.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "file.h"
#include "fcntl.h"



static int
argfd(int n, int *pfd, struct file **pf)
{
  int file_des;
  struct file *f;

  if(argint(n, &file_des) < 0)
    return -1;
  if(file_des < 0 || file_des >= NOFILE || (f=myproc()->ofile[file_des]) == 0)
    return -1;
  if(pfd)
    *pfd = file_des;
  if(pf)
    *pf = f;
  return 0;
}

static int
fdalloc(struct file *f)
{
  int file_des;
  struct proc *curproc = myproc();

  for(file_des = 0; file_des < NOFILE; file_des++){
    if(curproc->ofile[file_des] == 0){
      curproc->ofile[file_des] = f;
      return file_des;
    }
  }
  return -1;
}

int
sys_dup(void)
{
  struct file *f;
  int file_des;

  if(argfd(0, 0, &f) < 0)
    return -1;
  if((file_des=fdalloc(f)) < 0)
    return -1;
  filedup(f);
  return file_des;
}

int
sys_read(void)
{
  struct file *f;
  int n;
  char *p;

  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
    return -1;
  return fileread(f, p, n);
}

int
sys_write(void)
{
  struct file *f;
  int n;
  char *p;

  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
    return -1;
  return filewrite(f, p, n);
}

int
sys_close(void)
{
  int file_des;
  struct file *f;

  if(argfd(0, &file_des, &f) < 0)
    return -1;
  myproc()->ofile[file_des] = 0;
  fileclose(f);
  return 0;
}

int
sys_fstat(void)
{
  struct file *f;
  struct stat *st;

  if(argfd(0, 0, &f) < 0 || argptr(1, (void*)&st, sizeof(*st)) < 0)
    return -1;
  return filestat(f, st);
}


int
sys_link(void)
{
  char name[DIRSIZ], *new, *old;
  struct inode *dp, *ip;

  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)
    return -1;

  begin_op();
  if((ip = namei(old)) == 0){
    end_op();
    return -1;
  }

  ilock(ip);
  if(ip->type == T_DIR){
    iunlockput(ip);
    end_op();
    return -1;
  }

  ip->nlink++;
  iupdate(ip);
  iunlock(ip);

  if((dp = nameiparent(new, name)) == 0)
    goto bad;
  ilock(dp);
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    iunlockput(dp);
    goto bad;
  }
  iunlockput(dp);
  iput(ip);

  end_op();

  return 0;

bad:
  ilock(ip);
  ip->nlink--;
  iupdate(ip);
  iunlockput(ip);
  end_op();
  return -1;
}


static int
isdirempty(struct inode *dp)
{
  int off;
  struct dirent dest;

  for(off=2*sizeof(dest); off<dp->size; off+=sizeof(dest)){
    if(readi(dp, (char*)&dest, off, sizeof(dest)) != sizeof(dest))
      panic("isdirempty: readi");
    if(dest.inum != 0)
      return 0;
  }
  return 1;
}


int
sys_unlink(void)
{
  struct inode *ip, *dp;
  struct dirent dest;
  char name[DIRSIZ], *path;
  uint off;

  if(argstr(0, &path) < 0)
    return -1;

  begin_op();
  if((dp = nameiparent(path, name)) == 0){
    end_op();
    return -1;
  }

  ilock(dp);

  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    goto bad;

  if((ip = dirlookup(dp, name, &off)) == 0)
    goto bad;
  ilock(ip);

  if(ip->nlink < 1)
    panic("unlink: nlink < 1");
  if(ip->type == T_DIR && !isdirempty(ip)){
    iunlockput(ip);
    goto bad;
  }

  memset(&dest, 0, sizeof(dest));
  if(writei(dp, (char*)&dest, off, sizeof(dest)) != sizeof(dest))
    panic("unlink: writei");
  if(ip->type == T_DIR){
    dp->nlink--;
    iupdate(dp);
  }
  iunlockput(dp);

  ip->nlink--;
  iupdate(ip);
  iunlockput(ip);

  end_op();

  return 0;

bad:
  iunlockput(dp);
  end_op();
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    return 0;
  ilock(dp);

  if((ip = dirlookup(dp, name, 0)) != 0){
    iunlockput(dp);
    ilock(ip);
    if(type == T_FILE && ip->type == T_FILE)
      return ip;
    iunlockput(ip);
    return 0;
  }

  if((ip = ialloc(dp->dev, type)) == 0)
    panic("create: ialloc");

  ilock(ip);
  ip->major = major;
  ip->minor = minor;
  ip->nlink = 1;
  iupdate(ip);

  if(type == T_DIR){  
    dp->nlink++;  
    iupdate(dp);
    
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
      panic("create dots");
  }

  if(dirlink(dp, name, ip->inum) < 0)
    panic("create: dirlink");

  iunlockput(dp);

  return ip;
}

int
sys_open(void)
{
  char *path;
  int file_des, omode;
  struct file *f;
  struct inode *ip;

  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
    return -1;

  begin_op();

  if(omode & O_CREATE){
    ip = create(path, T_FILE, 0, 0);
    if(ip == 0){
      end_op();
      return -1;
    }
  } else {
    if((ip = namei(path)) == 0){
      end_op();
      return -1;
    }
    ilock(ip);
    if(ip->type == T_DIR && omode != O_RDONLY){
      iunlockput(ip);
      end_op();
      return -1;
    }
  }

  if((f = filealloc()) == 0 || (file_des = fdalloc(f)) < 0){
    if(f)
      fileclose(f);
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
  end_op();

  f->type = FD_INODE;
  f->ip = ip;
  f->off = 0;
  f->readable = !(omode & O_WRONLY);
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
  return file_des;
}

int
sys_mkdir(void)
{
  char *path;
  struct inode *ip;

  begin_op();
  if(argstr(0, &path) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    end_op();
    return -1;
  }
  iunlockput(ip);
  end_op();
  return 0;
}

int
sys_mknod(void)
{
  struct inode *ip;
  char *path;
  int major, minor;

  begin_op();
  if((argstr(0, &path)) < 0 ||
     argint(1, &major) < 0 ||
     argint(2, &minor) < 0 ||
     (ip = create(path, T_DEV, major, minor)) == 0){
    end_op();
    return -1;
  }
  iunlockput(ip);
  end_op();
  return 0;
}

int
sys_chdir(void)
{
  char *path;
  struct inode *ip;
  struct proc *curproc = myproc();

  begin_op();
  if(argstr(0, &path) < 0 || (ip = namei(path)) == 0){
    end_op();
    return -1;
  }
  ilock(ip);
  if(ip->type != T_DIR){
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
  iput(curproc->cwd);
  end_op();
  curproc->cwd = ip;
  return 0;
}

int
sys_exec(void)
{
  char *path, *argv[MAXARG];
  int i;
  uint uargv, uarg;

  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){
    return -1;
  }
  memset(argv, 0, sizeof(argv));
  for(i=0;; i++){
    if(i >= NELEM(argv))
      return -1;
    if(fetchint(uargv+4*i, (int*)&uarg) < 0)
      return -1;
    if(uarg == 0){
      argv[i] = 0;
      break;
    }
    if(fetchstr(uarg, &argv[i]) < 0)
      return -1;
  }
  return exec(path, argv);
}

int
sys_pipe(void)
{
  int *file_des;
  struct file *rf, *wf;
  int fd0, fd1;

  if(argptr(0, (void*)&file_des, 2*sizeof(file_des[0])) < 0)
    return -1;
  if(pipealloc(&rf, &wf) < 0)
    return -1;
  fd0 = -1;
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    if(fd0 >= 0)
      myproc()->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  file_des[0] = fd0;
  file_des[1] = fd1;
  return 0;
}

int sys_head()
{
    int numoflines;
    int file_des;

    argint(1, &numoflines);
    argint(0, &file_des);

    struct proc *existingproc = myproc();

   
    

    char buff[1024]; 

    int bytesTransfer = 0;
    struct file *f=existingproc->ofile[file_des];


    struct inode *ip;
    int size=sizeof(buff);

    

    ip = f->ip;
    ilock(ip);


    int linesPrinted = 0;
    char final_res[1024]="";
    while ((bytesTransfer = readi(ip, buff, f->off, size)) > 0 && linesPrinted < numoflines) {

        for (int i = 0; i < bytesTransfer; i++) {
            if (linesPrinted >= numoflines) {
                break;
            }

             
              final_res[i] = buff[i];
              
            if (buff[i] == '\n') {
                linesPrinted++;
            }
        }
        f->off+=bytesTransfer;
    }


    cprintf("%s\n",final_res);
    iunlock(ip);

    if (bytesTransfer < 0) {
        cprintf("Error reading file\n");
    } 
    return -1;
}

char custom_tolowercase(char c) {
    if (c >= 'A' && c <= 'Z') {
        return c + 'a' - 'A';
    }
    return c;
}


int stricmp1(const char *str1, const char *str2) {
    while (*str1 && *str2) {
        int difference = custom_tolowercase(*str1) - custom_tolowercase(*str2);
        if (difference != 0) {
            return difference;
        }
        str1++;
        str2++;
    }
    return custom_tolowercase(*str1) - custom_tolowercase(*str2);
}

int strcmp(const char *str1, const char *str2) {
    while (*str1 && *str2) {
        int difference = *str1 - *str2;
        if (difference != 0) {
            return difference;
        }
        str1++;
        str2++;
    }
    return *str1 - *str2;
}

char *strcpy(char *dest, const char *src) {
    char *orig_Dest = dest; 
    while (*src != '\0') {
        *dest = *src;
        dest++;
        src++;
    }

   
    *dest = '\0';

    return orig_Dest; 
}

int sys_uniq()
{
    int counter=0;
    int dupli_line=0;
    int file_des=0;

    int dp=0;
    int ct=0;
    int ignore_case=0;
    int argc=0;

   argint(0, &file_des);
   argint(1, &dp);
   argint(2, &ct); 
   argint(3, &ignore_case);
   argint(4,&argc);

    char curline[1024];
    char previous_line[1024] = "";
    int first_line = 1;

    
    struct proc *existingproc = myproc();
    struct file *f=existingproc->ofile[file_des];


    struct inode *ip;
    


    ip = f->ip;
    ilock(ip);

   
    
    int lenofline = 0;
    while (1)
    {
        char c;
        int n = readi(ip,&c, f->off,sizeof(char));
       
        if (n <= 0)
            break;

        curline[lenofline] = c;
        f->off+=1;
        lenofline++;

        if (c == '\n') {
            curline[lenofline] = '\0';
            lenofline = 0;

            int compareresult;

            if(ignore_case==1)
            {
                compareresult=stricmp1(curline, previous_line);
            }
            else
            {
              compareresult=strcmp(curline, previous_line);
            }
            if (compareresult != 0 || first_line==1)
            {

                if (ct==1 && !first_line)
                {
                    cprintf("%d %s", counter, previous_line);/
                    
                }
                if (dupli_line==1 && dp==1)
                {
                    cprintf("%s", previous_line); 
                    dupli_line = 0; 
                }
                if(ignore_case==1)
                {
                cprintf("%s", curline);
                }
                if(argc==2)
                {
                cprintf("%s", curline);
                }
                counter = 1;
                strcpy(previous_line, curline);
                first_line = 0;
            }
            else
            {
                if(dp==1)
                {
                    dupli_line=1;
                }
                counter++;
            }
          }
      }

      iunlock(ip);

      if (ct && counter > 0) {
          cprintf("%d %s", counter, previous_line);
      }
      if (dp && dupli_line)
      {
          cprintf("%s", previous_line);
      }
    return 0;
}
